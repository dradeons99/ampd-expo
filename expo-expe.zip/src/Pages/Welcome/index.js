import React, { Component } from "react";
import { Text } from "react-native";

const Welcome = () => {
  return <Text>Hal Welcome</Text>;
};
export default Welcome;

import React from "react";
import Sutm from "./sutm";
import Sutm2 from "./sutm2";
import Sktm from "./sktm";
import Sktm2 from "./sktm2";
import Tiang from "./tiang";
import Tiang2 from "./tiang2";
import Trafo from "./trafo";
import Trafo2 from "./trafo2";

export { Sutm, Sutm2, Sktm, Sktm2, Tiang, Tiang2, Trafo, Trafo2 };

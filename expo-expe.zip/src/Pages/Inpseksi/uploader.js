import React, { Component } from "react";
import { Text } from "react-native";

const Uploader = () => {
  return <Text>Hal Pemeliharaan</Text>;
};
export default Uploader;

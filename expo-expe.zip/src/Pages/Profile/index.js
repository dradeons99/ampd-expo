import React, { Component } from "react";
import { Text } from "react-native";

const Profile = () => {
  return <Text>Hal Profile</Text>;
};
export default Profile;

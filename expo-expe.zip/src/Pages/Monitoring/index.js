import React, { Component } from "react";
import { Text } from "react-native";

const Monitoring = () => {
  return <Text>Hal Monitoring</Text>;
};
export default Monitoring;

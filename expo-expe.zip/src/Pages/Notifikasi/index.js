import React, { Component } from "react";
import { Text } from "react-native";

const Notifikasi = () => {
  return <Text>Hal Notifikasi</Text>;
};
export default Notifikasi;

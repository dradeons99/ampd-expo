import React, { Component } from "react";
import { Text } from "react-native";

const Pemeliharaan = () => {
  return <Text>Hal Profile</Text>;
};
export default Pemeliharaan;
